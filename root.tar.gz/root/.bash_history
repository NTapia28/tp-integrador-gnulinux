history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
 ip a
hostnamectl set-hostname TPServer
cat /etc/hostname
vi /etc/hosts
clear
ls -l
pwd
cd /
ls -l
cd --
ls -la
clear
ping -c 3 deb.debian.org
lsb_release -a
apt update
apt upgrade
apt autoremove
vi /etc/apt/sources.list
clear
echo calha boca macaco
clear
apt update
apt full-upgrade
lsb_release -a
cat /etc/debian_version
apt-getinstall openssh-server
apt-get install openssh-server
vi /etc/ssh/sshd_config
clear
systemctl restart ssh
systemctl status ssh
ssh-keygen
ip a
ssh-copy-id root@10.0.2.15
chmod 700 /root/.ssh
chmod 600 /root/.ssh/id_rsa /root/.ssh/authorized_keys
chmod 644 /root/.ssh/id_rsa.pub
ip a
shutdown -h
shutdown -c
shutdown -h now
clear
exit
clear
clear
echo niggling
clear
ip a
vi /etc/network/interfaces
vi /etc/network/interfaces
pwd
vi /etc/network/interfaces
systemctl restart networking
ip a show enp0s3
ip r
ping -c 3 192.168.0.1
ping -c 3 deb.debian.org
shutdown -h now
lsblk
fdisk /dev/sdc
lsblk
lsblk /dev/sdc
fdisk -l /dev/sdc
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
mkdir /www_dir /backup_dir
pwd
ls -l
cd/
cd /
ls -l
rm -f /www_dir/
pwd
echo nigling
exit
shutdown -h now
clear
clear
nigga
clear
ls -l
ls root
cd root
cd /root
ls -l
pwd
cd /
ls -l
cd opt
ls -l
ls -l
cd --
ls -l
cd /
mkdir -p /opt/scripts
vi /opt/scripts/backup_full.sh
shutdown -h now
clear
ls -l
cd /
ls -l
cd opt/
ls -l
ls -ld scripts
cd /
cat > /opt/scripts/backup_full.sh <<'FIN_SCRIPT'
cdcat > /opt/scripts/backup_full.sh <<'FIN_SCRIPT'
#!/bin/bash
# =====================================================================
# backup_full.sh - Backup comprimido (.tar.gz) de un directorio.
# Uso: backup_full.sh <origen> [destino] (destino por defecto:
/backup_dir)
# Ej.: backup_full.sh /var/log /backup_dir
# genera /backup_dir/log_bkp_YYYYMMDD.tar.gz
# =====================================================================
# ===== Variables del programador (en mayusculas) =====
DESTINO_DEFAULT=/backup_dir
FECHA=`date +%Y%m%d`
# ===== Funciones =====
mostrar_ayuda () {
echo "Uso: $0 <origen> [destino]"
echo ""
echo " origen Directorio a resguardar (ej: /var/log, /www_dir)"
echo " destino Directorio donde se guarda el backup (por defecto:
$DESTINO_DEFAULT)"
echo " Tiene que ser un filesystem montado."
echo ""
echo "Opciones:"
echo " -help, -h, --help Muestra esta ayuda"
echo ""
echo "Genera: <destino>/<nombre-del-origen>_bkp_<YYYYMMDD>.tar.gz"
echo "Ejemplo: $0 /var/log /backup_dir"
}
validar_origen () {
if [[ ! -d "$ORIGEN" ]]; then
echo "ERROR: el origen $ORIGEN no existe o no es un directorio." >&2
exit 2
fi
df "$ORIGEN" > /dev/null 2>&1
if [[ $? -ne 0 ]]; then
TP integrador — resolución paso a paso
Page 22 of 45
echo "ERROR: el filesystem del origen $ORIGEN no esta disponible."
>&2
exit 2
fi
}
validar_destino () {
if [[ ! -d "$DESTINO" ]]; then
echo "ERROR: el destino $DESTINO no existe o no es un directorio."
>&2
exit 3
fi
mount | grep " $DESTINO " > /dev/null
if [[ $? -ne 0 ]]; then
echo "ERROR: $DESTINO no esta montado (no hay un filesystem montado
ahi)." >&2
exit 3
fi
if [[ ! -w "$DESTINO" ]]; then
echo "ERROR: no hay permiso de escritura en $DESTINO." >&2
exit 3
fi
}
# ===== Programa principal =====
case "$1" in
-help | -h | --help ) mostrar_ayuda ; exit 0 ;;
esac
if [[ $# -lt 1 ]]; then
echo "ERROR: falta indicar el origen." >&2
mostrar_ayuda >&2
exit 1
fi
ORIGEN=${1%/}
DESTINO=${2:-$DESTINO_DEFAULT}
DESTINO=${DESTINO%/}
validar_origen
validar_destino
NOMBRE=`basename "$ORIGEN"`
PADRE=`dirname "$ORIGEN"`
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"
TP integrador — resolución paso a paso
Page 23 of 45
tar -czf "$ARCHIVO" -C "$PADRE" "$NOMBRE"
RC=$?
if [[ $RC -le 1 ]]; then
if [[ $RC -eq 1 ]]; then
echo "AVISO: algunos archivos cambiaron mientras se copiaban."
fi
TAMANIO=`du -h "$ARCHIVO" | cut -f1`
echo "OK: backup generado en $ARCHIVO ($TAMANIO)"
exit 0
else
echo "ERROR: tar fallo (codigo $RC)." >&2
rm -f "$ARCHIVO"
exit 4
fi
FIN_SCRIpt


