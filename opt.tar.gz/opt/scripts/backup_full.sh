#!/bin/bash
DESTINO_DEFAULT=/backup_dir
FECHA=`date +%Y%m%d`

mostrar_ayuda () {
echo "Uso: $0 <origen> [destino]"
echo ""
echo " origen Directorio a resguardar (ej: /var/log, /www_dir)"
echo " destino Directorio donde se guarda el backup (por defecto:
$DESTINO_DEFAULT)"
echo " Tiene que ser un filesystem montado."
echo ""
echo "Opciones:"
echo " -help, -h, --help Muestra esta ayuda"
echo ""
echo "Genera: <destino>/<nombre-del-origen>_bkp_<YYYYMMDD>.tar.gz"
echo "Ejemplo: $0 /var/log /backup_dir"
}

validar_origen () {
if [[ ! -d "$ORIGEN" ]]; then
echo "ERROR: el origen $ORIGEN no existe o no es un directorio." >&2
exit 2
fi
df "$ORIGEN" > /dev/null 2>&1
if [[ $? -ne 0 ]]; then
echo "ERROR: el filesystem del origen $ORIGEN no esta disponible."
>&2
exit 2
fi
}

validar_destino () {
if [[ ! -d "$DESTINO" ]]; then
echo "ERROR: el destino $DESTINO no existe o no es un directorio."
>&2
exit 3
fi
mount | grep " $DESTINO " > /dev/null
if [[ $? -ne 0 ]]; then
echo "ERROR: $DESTINO no esta montado (no hay un filesystem montado
ahi)." >&2
exit 3
fi
if [[ ! -w "$DESTINO" ]]; then
echo "ERROR: no hay permiso de escritura en $DESTINO." >&2
exit 3
fi
}

case "$1" in
-help | -h | --help ) mostrar_ayuda ; exit 0 ;;
esac
if [[ $# -lt 1 ]]; then
echo "ERROR: falta indicar el origen." >&2
mostrar_ayuda >&2
exit 1
fi
ORIGEN=${1%/}
DESTINO=${2:-$DESTINO_DEFAULT}
DESTINO=${DESTINO%/}
validar_origen
validar_destino
NOMBRE=`basename "$ORIGEN"`
PADRE=`dirname "$ORIGEN"`
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"
tar -czf "$ARCHIVO" -C "$PADRE" "$NOMBRE"
RC=$?
if [[ $RC -le 1 ]]; then
if [[ $RC -eq 1 ]]; then
echo "AVISO: algunos archivos cambiaron mientras se copiaban."
fi
TAMANIO=`du -h "$ARCHIVO" | cut -f1`
echo "OK: backup generado en $ARCHIVO ($TAMANIO)"
exit 0
else
echo "ERROR: tar fallo (codigo $RC)." >&2
rm -f "$ARCHIVO"
exit 4
fi


